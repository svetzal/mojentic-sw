import hashlib,json,re,subprocess,time
from pathlib import Path
files=subprocess.check_output(['git','ls-files','-z']).decode().split('\0')
files=sorted(set(f for f in files if f and not f.startswith(('.foundry/','docs/evidence/')))|{'scripts/verify-recovery-evidence.py'})
hashes={f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in files}
Path('.foundry/tested-source.json').write_text(json.dumps(hashes,indent=2)+'\n')
gates=json.loads(Path('.hone-gates.json').read_text())['gates']
gates += [{'name':'security','command':'osv-scanner scan source --lockfile=Package.resolved'}, {'name':'example','command':'python3 scripts/probe-recovery-example.py'}]
results=[]
for gate in gates:
 start=time.time_ns()
 command=['foundry','capture','--log-dir','.foundry/logs','--','sh','-c',gate['command']]
 proc=subprocess.run(command,capture_output=True,text=True)
 end=time.time_ns()
 print(gate['name'],proc.returncode,proc.stdout,proc.stderr,flush=True)
 logs=re.findall(r'(?:stdout|stderr): (.+)',proc.stdout+proc.stderr)
 assert len(logs)==2,(proc.stdout,proc.stderr)
 results.append({'name':gate['name'],'command':gate['command'],'exit_code':proc.returncode,'start_unix_ns':start,'end_unix_ns':end,'logs':logs})
 Path('.foundry/validation-results.json').write_text(json.dumps(results,indent=2)+'\n')
 if proc.returncode:raise SystemExit(proc.returncode)
assert all(hashlib.sha256(Path(f).read_bytes()).hexdigest()==h for f,h in hashes.items())
