import re, subprocess
from pathlib import Path
p = Path('RECOVERY-CONFORMANCE.md')
s = p.read_text()
old = subprocess.check_output(['git', 'show', 'HEAD:RECOVERY-CONFORMANCE.md'], text=True)
assert not re.search(r'\b(cycle|foundry|controller)\b', s, re.I)
assert s.split('## Focused validation evidence')[0] == old.split('## Cycle 22 acceptance ordering')[0]
assert s.split('## Validation scope')[1] == old.split('## Validation scope')[1]
a = old.index('| Focused coverage |')
b = old.index('The durable receipt')
assert old[a:b] in s
for value in ['5ebb0a11ab977a1d2e614744ed85e535ac759b52', 'a53a3a4eb118fa4687dd703d6ce918dd40dd6cb4eda796abc6c429a6e932e7a3', '75 calls', 'zero independent byte/ordering violations', 'zero HTTP timeouts', 'cannot reconstruct the\noriginal failures.', '## Public entrypoints', 'exit 0']:
    assert value in s, value
readme = Path('Examples/RecoveryExample/README.md').read_text()
assert 'RECOVERY-CONFORMANCE.md#public-entrypoints' in readme
assert subprocess.check_output(['git', 'diff', '--name-only'], text=True).splitlines() == ['RECOVERY-CONFORMANCE.md']
print('PASS: vocabulary removed; source/contract identities, validation results, complete coverage mappings, historical limits and public anchor preserved; only requested record changed')
