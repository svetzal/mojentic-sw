# Independent skeptical review — Cycle 22 acceptance ordering

Reviewed before broad validation. Scope: read-only independent review of the focused acceptance evidence, delivered source assertions, current RECOVERY-CONFORMANCE.md Cycle 22 addition, and preserved reconciliation mappings. No broad gates or live inference were run by this reviewer.

## Verdict

PASS for the focused acceptance ordering and coverage correction; no blocking inaccurate assertion found. Final completion remains conditional on all configured gates, OSV/example checks, and verification of the final durable receipt manifest. This review does not claim those checks have already passed.

The tested source is trunk 5ebb0a11ab977a1d2e614744ed85e535ac759b52. Baseline SHA-256 hashes independently recomputed from current files match all recorded source/test/script hashes except RECOVERY-CONFORMANCE.md, the intended documentation edit. The retained authoritative contract independently hashes to a53a3a4eb118fa4687dd703d6ce918dd40dd6cb4eda796abc6c429a6e932e7a3. No executable contract or runtime change occurred. The initial focused test and correlation logs end with success; their actual exit 0 results are separately retained in acceptance-result.json. Exact process-exit timestamps were not collected for these initial commands: Foundry capture identifiers provide starts and completion observations/log-write bounds provide ends. These bounds support ordering before broad validation without claiming exact process-exit times.

## Coverage and assertions inspected

The correlation contains 75 distinct labeled calls: 40 framing calls (20 incomplete/framed pairs), two ownership calls, and 33 public interruption calls. Every adapter is present: Ollama, oMLX, OpenAI, Anthropic. Each adapter has tool-stream framing pairs at gateway, broker, session and single-turn pairs at gateway, broker. Single-turn session is deliberately inapplicable. Public interruption has 32 matrix cases: content/reasoning/tool at broker and session tool streams, content/reasoning at single-turn broker, for all four adapters. One additional Ollama content-plus-unfinished-tool session case exercises rollback. The two independent ownership cases are Ollama broker single-turn and session tool-stream; they do not pretend to be a four-adapter ownership matrix.

SenderRegistrationCancellationTests first waits on actual HTTP prefix receipt, asserts no registration, then either terminates the incomplete record or independently releases its suffix. SenderRegistrationFramingEvidence asserts no semantic progress for the incomplete record, exact typed transport termination, exact expected lifecycle and observed bytes. The framed branch reaches the real sender registration before cancellation. These are actual boundary behaviors, not marker/count-only evidence. Registration role selection is separately checked by the ownership cases and schedule helper.

SenderRegistrationCancellationEvidence and PublicInterruptionCapture compare wire-anchored structured logical/attempt identities, one-based wire number, exact response evidence, typed original URLError causes, full expected event equality, and independently constructed observed/delivered progress. RecoveryLifecycleEvidence derives provider/operation from test inputs and UUIDs from request capture, not from actual lifecycle output; it constructs every expected lifecycle field. Public interruption compares exact delivered Unicode content/reasoning prefixes, forbids unexpected trailing events, requires a single interrupted request after any seed, zero admission calls and zero CountingTool execution, and checks seeded session messages roll back unchanged. Hidden reasoning and withheld tools rendezvous on observed HTTP bytes because no public semantic delivery exists; this distinction is explicit in the test.

For framed and ownership sender cancellation, finishCancellation checks expected actual producer task completions, HTTP delegate completion, and peer FIN while the fixture remains held, before draining the stream or resuming the paused consumer. Incomplete framing separately checks successful socket close and terminal producer completion before resumption. The correlation independently checks byte agreement and completion/resumption ordering; coverage-verified.json additionally checks unique socket request correlation and unmasked distinct identity objects, including seed requests. I inspected these mechanisms and the 75 labeled correlation entries; this is more than trusting a test count.

Important precision: all 20 paired raw request-byte equality comparisons are false because JSON encoding key order can differ. Exact bytes are retained and matched within each call; requests across the paired calls compare as decoded JSON values. The record correctly states this. Likewise, lifecycle semantic equality comes from the Swift assertions; merely seeing three structured lifecycle records in Python would not independently prove every expected field. The record appropriately relies on both the executable assertions and correlation.

## Nine original gaps

Focused execution directly supports gap 4 (public partial interruption) and gap 6 (typed causes, complete lifecycle and cleanup), and preserves the historical evidence limit. Gaps 1–3, 5 and 7–9 retain the existing executable mappings in the reconciliation table; they need the subsequent broad full-traits/default tests and applicable documentation/example/security checks, not extrapolation from these 75 calls.

## All twelve binding decisions

| Decision | Evidence and limits at this review stage |
| --- | --- |
| 1 Remote/local admission without hook | Preserved RecoveryAdmissionContractTests.providerAdmissionRules; synthetic local acceptance-no remains limited to pre-dispatch evidence. Requires broad tests. |
| 2 Undecided is not rejection | Preserved emptyAdmissionDoesNotReject; distinct admissionUndecided and no resend. Requires broad tests. |
| 3 Five capabilities | Preserved gateway capability table and mapped suites, including trait-enabled Anthropic. Focused streaming checks are not proof of buffered/structured/JSON paths. Requires broad tests. |
| 4 Safe metadata | Preserved metadata/privacy suites in gap 2. Focused raw private evidence does not replace metadata validation. Requires broad tests. |
| 5 HTTP dates | RecoveryHTTPDateTests exists and maps all forms through gap 3; not executed in focused run. Requires broad tests. |
| 6 Closed provider/operation | Focused expected lifecycle equality exercises all four typed providers and streaming operation; buffered/structured mappings remain broad-test responsibilities. |
| 7 oMLX keepalives | Preserved OMLXRecoveryKeepAliveTests for both stream APIs and guards. Ordinary framing probes are not keepalive proof. Requires broad tests. |
| 8 Typed errors | Focused transport/cancellation URLError cause preservation and identity/report/history checks pass; policy/capture/length error mappings are preserved in TypedRecoveryErrorTests and need broad tests. |
| 9 Public interruption | Directly verified by PublicRecoveryInterruptionTests and support across all adapters/applicable paths, exact observed/delivered prefixes, one interrupted request, zero tools, seeded rollback. Gateway semantic interruption mapping remains in StreamingRecoveryTests. |
| 10 Lifecycle/policy/jitter/admission | Focused full lifecycle and cleanup pass. RecoveryPolicySelectionTests, RecoveryBoundedTimingTests and admission cancellation/expiry mappings remain preserved and need broad tests. |
| 11 Reflection/privacy | RecoveryReflectionTests exists and mappings preserve exact children/sentinel exclusion. Not inferred from unmasked opt-in traces. Requires broad tests. |
| 12 Docs/migration/example | Preserved DocC/Unreleased guidance, typed vocabulary, oMLX docs, RecoveryExample and actual HTTP resend probe mappings. Requires DocC and example checks after this review. |

## Evidence limitations and finalization requirements

These replacement observations establish only their own controlled interleavings. They cannot reconstruct original historical readiness/timeout/malformed-tail/interruption causes or establish production cancellation failure. The record preserves that limitation. Linux does not establish Apple-platform or minimum Swift 6.1 results. No other repository verified a shared executable contract in this task; no cross-repository boundary changed.

The receipt currently exists outside the disposable worktree and contains complete focused logs/captures/correlation/baseline contract and source hashes. Its eventual statement that all gate evidence and the final integrated source are verified must be backed by the final manifest and actual gates; until then that wording describes the required completion state, not an already observed result. Keep initial command times labeled as capture/observation bounds. Final source hashing should distinguish the unchanged tested executable source from the edited documentation. A changed runtime/test/helper hash would require renewed focused verification. All configured gates and applicable OSV/example checks remain necessary despite this acceptance PASS.
