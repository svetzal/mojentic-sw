from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile
import time

root = Path.cwd()
r = Path('/home/svetzal/.foundry/tool-logs/mojentic-sw-cycle22-5ebb0a11')
names = ['format','lint','build','test','test-full-traits','docs','security','example']
results = [json.loads((r/(name+'-result.json')).read_text()) for name in names]
assert all(v['exit_code']==0 for v in results)
assert all(v['logs'] and all((r/p).is_file() for p in v['logs']) for v in results)
assert all(a['end_unix_ns']<=b['start_unix_ns'] for a,b in zip(results,results[1:]))
assert (r/'independent-review.md').stat().st_mtime_ns < results[0]['start_unix_ns']
acceptance = json.loads((r/'acceptance-result.json').read_text())
assert acceptance['commands'][1]['last_log_write_unix_ns'] < (r/'independent-review.md').stat().st_mtime_ns
tracked = subprocess.check_output(['git','ls-files','-z']).decode().split('\0')
hashes={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in tracked if p and Path(p).is_file()}
assert all(v['source_hashes']==hashes for v in results), 'Exact integrated source must remain unchanged through every gate'
baseline=json.loads((r/'baseline-source-hashes.json').read_text())
changed=sorted(p for p in hashes if hashes[p]!=baseline[p])
assert changed==['RECOVERY-CONFORMANCE.md'],changed
(r/'all-tracked-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
project_hashes={p:digest for p,digest in hashes.items() if not p.startswith('.foundry/')}
(r/'integrated-source-hashes.json').write_text(json.dumps(project_hashes,indent=2)+'\n')
with tarfile.open(r/'integrated-source.tar.gz','w:gz') as archive:
 for p in project_hashes: archive.add(p,arcname=p,recursive=False)
(r/'source.diff').write_bytes(subprocess.check_output(['git','diff','--','RECOVERY-CONFORMANCE.md']))
shutil.copy2('.foundry/logs/corrected.log',r/'corrected.log')
shutil.copy2('.foundry/proof.json',r/'proof.json')
shutil.copy2('.foundry/run-evidence.py',r/'run-evidence.py')
shutil.copy2('.foundry/run-gates.py',r/'run-gates.py')
shutil.copy2('.foundry/finalize-receipt.py',r/'finalize-receipt.py')
contract=hashlib.sha256((r/'authoritative-contract.md').read_bytes()).hexdigest()
assert contract==acceptance['authoritative_contract_sha256']
proof=json.loads((r/'proof.json').read_text())
assert proof['kind']=='direct' and isinstance(proof['reason'],str) and proof['reason'].strip()
assert type(proof['corrected']['exit_code']) is int and proof['corrected']['exit_code']==acceptance['test_exit_code']==0
assert Path(proof['corrected']['log']).is_file()
receipt={'id':r.name,'tested_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'changed_files':changed,'authoritative_contract_sha256':contract,'acceptance_calls':75,'framing_pairs':20,'acceptance_exit_code':0,'correlation_exit_code':0,'review':'independent-review.md','ordering':'remote HEAD match, focused acceptance, correlation, independent review, all six configured gates, OSV, scripted example','command_timing_limit':acceptance['end_timestamp_limit'],'checks':[{k:v[k] for k in ['name','command','start_unix_ns','end_unix_ns','exit_code','logs']} for v in results],'source_hashes':'integrated-source-hashes.json','hash_scope':'Gate source_hashes retain every pre-existing tracked file including historical scratch logs; integrated-source-hashes and source snapshot exclude .foundry scratch. all-tracked-hashes preserves the complete comparison.','source_snapshot':'integrated-source.tar.gz','contract_verification':'No cross-repository boundary changed. Only this Swift commit and its scripted fixtures were verified; no sibling-port provider verification claimed.','historical_limit':'Replacement calls cannot reconstruct original failures.','platform_limit':'Swift 6.4 Linux only; Apple-platform and minimum Swift 6.1 validation remain pending.','finalized_unix_ns':time.time_ns()}
(r/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
manifest={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(r.rglob('*')) if p.is_file() and p.name!='manifest.json'}
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for p,digest in json.loads((r/'manifest.json').read_text()).items():
 assert hashlib.sha256((r/p).read_bytes()).hexdigest()==digest,p
print(f'Verified durable receipt: {len(manifest)} files, all eight checks passed, unchanged integrated source, ordered review and validation.')
