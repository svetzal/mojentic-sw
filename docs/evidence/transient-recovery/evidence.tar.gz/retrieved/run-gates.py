import json
from pathlib import Path
import shlex
import subprocess
import sys

receipt = Path('/home/svetzal/.foundry/tool-logs/mojentic-sw-cycle22-5ebb0a11')
assert (receipt / 'independent-review.md').is_file(), 'Independent review must precede broad validation'
gates = json.loads(Path('.hone-gates.json').read_text())['gates']
checks = [(g['name'], shlex.split(g['command'])) for g in gates]
checks += [('security', ['osv-scanner', 'scan', 'source', '--lockfile=Package.resolved']),
           ('example', ['python3', 'scripts/probe-recovery-example.py'])]
for name, command in checks:
    result = subprocess.run(['python3', '.foundry/run-evidence.py', name, *command])
    if result.returncode:
        sys.exit(result.returncode)
