import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

root = Path.cwd()
durable = Path('/home/svetzal/.foundry/tool-logs/mojentic-sw-cycle22-5ebb0a11')
name = sys.argv[1]
command = sys.argv[2:]
logs = root / '.foundry/logs'
before = set(logs.glob('*.log'))
tracked = subprocess.check_output(['git', 'ls-files', '-z']).decode().split('\0')
hashes = {p: hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in tracked if p and Path(p).is_file()}
start = time.time_ns()
result = subprocess.run(['foundry', 'capture', '--log-dir', str(logs), '--', *command])
end = time.time_ns()
new = sorted(set(logs.glob('*.log')) - before)
for p in new:
    shutil.copy2(p, durable / p.name)
record = {'name': name, 'command': command, 'start_unix_ns': start, 'end_unix_ns': end, 'exit_code': result.returncode, 'logs': [p.name for p in new], 'source_hashes': hashes}
(durable / (name + '-result.json')).write_text(json.dumps(record, indent=2) + '\n')
print(f'{name}: actual exit {result.returncode}, complete logs retained in {durable}', flush=True)
sys.exit(result.returncode)
